package com.task;

import javax.persistence.GenerationType;

import org.springframework.data.jpa.repository.JpaRepository;

public @interface GeneratedValue {

	GenerationType strategy();
	


}

package com.task;

import java.util.List;
import java.util.Optional;

import org.springframework.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

public interface productRepository 
{
	public interface ProductRepository extends JpaRepository<Product, Long> 
	{
	
		@RestController
		@RequestMapping("/api/products")
		public class ProductController {
		    @Autowired
		    private ProductRepository productRepository;

		    @GetMapping
		    public List<Product> getAllProducts() {
		        return productRepository.findAll();
		    }

		    @GetMapping("/{id}")
		    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
		        Optional<Product> product = productRepository.findById(id);
		        return product.map(response -> ResponseEntity.ok().body(response))
		                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		    }

		    @PostMapping
		    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
		        Product savedProduct = productRepository.save(product);
		        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
		    }

		    @PutMapping("/{id}")
		    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product product) {
		        if (!productRepository.existsById(id)) {
		            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		        }
		        Product updatedProduct = productRepository.save(product);
		        return new ResponseEntity<>(updatedProduct, HttpStatus.OK);
		    }

		    @DeleteMapping("/{id}")
		    public ResponseEntity<String> deleteProduct(@PathVariable Long id) {
		        productRepository.deleteById(id);
		        return new ResponseEntity<>("Product has been deleted", HttpStatus.OK);
		    }
		}

	
	
	}

}
